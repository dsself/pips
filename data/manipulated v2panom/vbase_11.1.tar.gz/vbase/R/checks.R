#' Show duplicates from a data.frame
#'
#' Show the duplicates of a data.frame based on spcified columns
#' The output data.frame shows the original value and the duplicates.
#' @param df A data.frame.
#' @param cols A character vector of column names
#'
#' @export
duplicates <- function(df, cols) {
    rbind(df[duplicated(df[, cols]), ],
          df[duplicated(df[, cols], fromLast = T), ])
}

#' Test for duplicates in a data.frame
#'
#' @export
no_duplicates <- function(df, cols) {
    nrow(duplicates(df, cols)) == 0L
}
