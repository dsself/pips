#' Check all forked processes.
#'
#' Waits for all forked processes to finish and checks their return values
#' @export
all_forks_done <- function(pattern = "fork", forklist) {
    if (!missing(forklist)) {
        ll <- parallel::mccollect(mget(forklist, envir = .GlobalEnv))
    } else {
        ll <- prallel::mccollect(mget(ls(pattern = "fork\\d+",
                                         envir = .GlobalEnv),
                                      envir = .GlobalEnv))
    }

    all(unlist(lapply(ll, is.null)))
}
