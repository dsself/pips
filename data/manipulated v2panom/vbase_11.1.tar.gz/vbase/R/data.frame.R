#' Remove tibble class attritubes from data.frame
#' @export
untibble <- function(tibtib) {
    stopifnot("data.frame" %in% class(tibtib))
    class(tibtib) <- class(tibtib)[!class(tibtib) %in% c("tbl_df", "tbl")]
    return(tibtib)
}


#' Determine column types of a data.frame
#'
#' @description
#' Determine column types of data.frame
#'
#' @return Named character vector of coulmn types.
#'
#' @export
column_types <- function(df) {
    lapply(df, class) %>% unlist
}

#' Round the numeric columns of a data.frame
#'
#' @param df A data.frame
#' @param n Decimal position for rounding
#' @return A data.frame
#' @export
round_df <- function(df, n) {
    df[] <- lapply(df, function(v) {
        if (is.numeric(v)) {
            round(v, n)
        } else {
            v
        }
    })
    return(df)
}

#' @export
compare_column_types <- function(...) {
    ll <- list(...)
    # Works with several objects or list of objects
    if (length(ll) == 1)
        ll <- ll[[1]]
    nn <- names(ll)
    # If function call is without names then create them.
    if (is.null(nn)) {
        nn <- 1:length(ll) %>% as.character
        names(ll) <- nn
    }
    
    out <- Map(function(df, nn) {
        outdf <- data.frame(names = names(df))
        outdf[[nn %^% "_class"]] <- lapply(df, 
                        function(v) paste(class(v), collapse = ",")) %>% unlist
        return(outdf)
    }, df = ll, nn = names(ll))

    common_cols <- lapply(out, function(df) {
        df$names
    }) %>% unlist %>% table %>% as.data.frame(stringsAsFactors = FALSE) %>% 
        dplyr::filter(Freq > 1) %>% {.[, 1]}

    res <- Reduce(partial(dplyr::full_join, by = "names"), out) %>%
        dplyr::filter(names %in% common_cols)

    no_clash <- apply(res[, -1], 1, function(v) {length(unique(na.omit(v))) == 1})
    
    if (nrow(res[!no_clash, ]) > 0) {
        info("There are column type clashes")
        return(res[!no_clash, ])
    } else {
        info("There are no column type clashes.")
    }
    
}



#' Check columns of a data.frame or matrix for strange values
#'
#' Goes through column by column to check for NA's, Dates out of
#' range, empty strings etc.
#'
#' @param df A data.frame or a matrix object
#'
#' @examples
#' df <- data.frame(a = c(NA, 1, 2), b = c("", "A", NA),
#'                  stringsAsFactors = FALSE)
#' check_columns(df)
#'
#' @export
check_columns <- function(df) UseMethod("check_columns")

#' @export
check_columns.data.frame <- function(df) {
    if (!is.data.frame(df))
        stop("Object checked is no data.frame!")

    # Determine functions to check for each cell by type, must
    # evaluate to logical
    char_funs <- c(is.na,
                   function(x) x == "",
                   function(x) grepl("\n", x, fixed = T),
                   function(x) grepl("\r", x, fixed = T),
                   function(x) trimws(x, which = "both") != x)
    num_funs <- c(is.na,
                  is.nan,
                  function(x) x < 0)
    date_funs <- c(is.na,
                   function(x) x > Sys.Date(),
                   function(x) x < as.Date(c("17880101"), format = '%Y%m%d'))
    factor_funs <- c(function(x) T,
                     is.na)
    other_funs <- c(is.na)

    # Name functions for output
    names(char_funs) <- c("NA", "''", "\\n", "\\r", "leading or trailing white spaces")
    names(num_funs) <- c("NA", "NaN", "<0")
    names(date_funs) <- c("NA", "> today", "< 1788-01-01")
    names(factor_funs) <- c("type!", "NA")
    names(other_funs) <- c("NA")

    # Check each cell in each column
    check_cols_f <- function(df, funs, n = names(funs), type) {
        if (nrow(df) == 0)
            return(NULL)

        invisible(lapply(seq_along(funs), function(x, n, f) {
            res <- Filter(isTRUE, unlist(lapply(lapply(df, f[[x]]), any)))

            if (length(res) > 0) {
                sprintf("Column(s) %s have: %s %s",
                        paste(names(res), collapse = ", "),
                        type,
                        n[x]) %>% warn
            }
        }, n = n, f = funs))
    }

    # Split data.frame into types
    df_char <- df[, lapply(df, class) == "character", drop = F]
    df_num <- df[, lapply(df, class) == "numeric", drop = F]
    df_date <- df[, lapply(df, class) == "Date", drop = F]
    df_factor <- df[, lapply(df, class) == "factor", drop = F]
    df_other <- df[, !colnames(df) %in% c(colnames(df_char), colnames(df_num),
                                         colnames(df_date), colnames(df_factor)), drop = F]

    # Call sub functions on each sub data.frame
    check_cols_f(df_num, num_funs, type = "numeric")
    check_cols_f(df_char, char_funs, type = "character")
    check_cols_f(df_date, date_funs, type = "Date")
    check_cols_f(df_factor, factor_funs, type = "factor")
    check_cols_f(df_other, other_funs, type = "Other")
}

#' @export
check_columns.matrix <- function(df)
    check_columns.data.frame(as.data.frame(df, stringsAsFactors = F))

#' Wrapper around dplyr filter (needs to be fixed)
#'
#' @export
fgrepl <- function(df, pattern, x, ...) {
    bool <- grepl(pattern, df[[x]])
    df[bool, ]
}

#' @export
df_compare <- function(dfnew, dfold, keep_cols = FALSE) {

    # check columns and compare only common ones
    diffcols1 <- setdiff(colnames(dfnew), colnames(dfold))
    diffcols2 <- setdiff(colnames(dfold), colnames(dfnew))
    common_cols <- intersect(colnames(dfnew), colnames(dfold))
    newcols <- if (!keep_cols) {
        common_cols
    } else {
        union(colnames(dfnew), colnames(dfold))
    }




    if (any(unlist(lapply(dfnew[, common_cols], class)) != 
        unlist(lapply(dfold[, common_cols], class))))
        stop("Column types are different!")

    if (length(diffcols1) > 0 | length(diffcols2) > 0) {
        if(length(diffcols1) > 0)
            info("additional columns in dfnew: " %^% diffcols1)
        if(length(diffcols2) > 0)
            info("additional columns in dfold: " %^% diffcols2)
        dfnew <- dplyr::select(dfnew, dplyr::any_of(newcols))
        dfold <- dplyr::select(dfold, dplyr::any_of(newcols))
    }

    out1 <- dplyr::anti_join(dfold, dfnew, by = common_cols)
    out2 <- dplyr::anti_join(dfnew, dfold, by = common_cols)
    if (nrow(out1) > 0) out1$dfdiff <- "-"
    if (nrow(out2) > 0) out2$dfdiff <- "+"
    if (nrow(out1) == 0 & nrow(out2) == 0)
        return(data.frame())
    dplyr::bind_rows(out1, out2) %>% dplyr::select(dfdiff, everything())
}

#' @export
df_compare_keep_pairs_only <- function(df, group_cols) {
    split(df, lapply(group_cols, function(v) df[[v]])) %>%
        lapply(., function(subdf) {
            if (nrow(subdf) != 2)
                return(NULL)
            return(subdf)
        }) %>% 
        dplyr::bind_rows(.) %>%
        sort_df(., group_cols)
}


#' @export
df_compare_pairs <- function(df, group_cols, result = c("data.frame", "colnames")) {
    stopifnot("dfdiff" %in% names(df))
    stopifnot(result %in% c("data.frame", "colnames"), length(result) == 1)

    df <- sort_df(df, c(group_cols, "dfdiff"))
    df$dfdiff <- NULL
    v <- names(df)
    group_cols_bool <- names(df) %in% group_cols_bool


    split(df, lapply(group_cols, function(v) df[[v]])) %>%
        lapply(., function(pairdf) {
            print(pairdf[[group_cols[1]]][1] %^% pairdf[[group_cols[2]]][1])
            bool <- ((pairdf[1, ] != pairdf[2, ]) | (is.na(pairdf[1, ]) != is.na(pairdf[2, ])))
            if (result == "data.frame") {
                return(pairdf[, group_cols_bool | bool])
            }
            if (result == "colnames") {
                return(paste(v[which(bool)], collapse = ","))
            }            
        })
}

#' @export
sort_df <- function(df, cols) {
    df[do.call(order, lapply(cols, function(v) df[[v]])), ]
}

#' @export
recycle_df <- function(df, n) {
    lapply(1:n, function(i) {
        df
    }) %>% dplyr::bind_rows(.)
}
