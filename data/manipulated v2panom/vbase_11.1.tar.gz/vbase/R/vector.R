#' @export
zipper <- function(...) {
    ll <- list(...)
    stopifnot(lapply(ll, length) %>% unlist %>% unique %>% {length(.) == 1})
    lapply(1:length(ll[[1]]), function(i) {
        lapply(ll, function(v) {
            v[i]
        }) %>% Reduce(c, .)
    }) %>% Reduce(c, .)
}

#' @export
zipper_names <- function(v, suffix = c("", "_old")) {
    clean_v <- v %>% gsub(suffix[1], "", .) %>% gsub(suffix[2], "", .)
    nonidents <- v[clean_v %^% suffix[1] %in% v & clean_v %^% suffix[2] %in% v]
    idents <- v[!v %in% nonidents]
    first_vars <- nonidents[1:(length(nonidents) / 2)]
    second_vars <- v[!v %in% c(idents, first_vars)]
    return(c(idents, zipper(first_vars, second_vars)))
}

#' @export
remove_items <- function(v, items) {
    not_contained <- items[!items %in% v]
    if (length(not_contained) > 0)
        print("These items do not exist in the vector: " %^% not_contained)
    v[!v %in% items]
}

#' @export
create_index <- function(v, na_index = TRUE) {
    out <- v != dplyr::lag(v)
    out[1] <- TRUE
    if (na_index)
        out[is.na(out)] <- TRUE
    return(cumsum(out))
}