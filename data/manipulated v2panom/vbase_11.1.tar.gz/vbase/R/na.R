#' @export
allNA <- function(obj) {
    all(is.na(obj))
}

#' @export
set_NA <- function(obj, bool) {
    if (is.matrix(bool))
        stop("bool is already a matrix!")
    is.na(obj) <- bool_to_matrix(bool, ncol(obj))
    return(obj)
}

#' @export
bool_to_matrix <- function(bool, n) {
    matrix(rep(bool, n), ncol = n)
}