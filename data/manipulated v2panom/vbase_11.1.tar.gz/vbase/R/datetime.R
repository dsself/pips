

#' @export
as.date <- function(v) {
    as.Date(v, format = "%Y-%m-%d")
}

