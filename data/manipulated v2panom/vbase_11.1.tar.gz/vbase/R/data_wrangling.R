#' Apply a function per group and combine results
#'
#' Simple wrapper around the conventional split-lapply-unsplit pattern
#' that, unlike \code{\link{by}}, returns a combined object.
#'
#' @param x An R object, either \code{data.frame} or \code{matrix}
#' @param factors Factor or list of factors passed to
#'     \code{\link{split}} and \code{\link{unsplit}}
#' @param fn Function to apply to each group
#' @param mc.cores Number of cores to use as parallel jobs.
#' @param ... Additional arguments passed to
#'     \code{\link[parallel]{mclapply}}
#'
#' @section Warning: \code{by_split} assumes that the subsets returned
#'     by the function \code{f} are of the same class as the
#'     original object.
#'
#' @return Object of same class as \code{x}.
#'
#' @examples
#' df <- data.frame(x = c(1, 1, 2, 2), y = c(1, NA, NA, 4))
#' by_split(df, df$x, locf)
#'
#' @export
by_split <- function(x, factors, fn, mc.cores = 1, ...) {
    if (class(fn) != "function")
        stop("Invalid function")

    UseMethod("by_split")
}

#' @export
by_split.matrix <- function(x, factors, fn, mc.cores = 1, ...) {
    ll <- split.data.frame(x, factors) %>%
        parallel::mclapply(fn, mc.cores = mc.cores, ...)

    mc_assert(ll)
    names(ll) <- NULL

    do.call(rbind, ll)
}

#' @export
by_split.data.frame <- function(x, factors, fn, mc.cores = 1, ...) {
    ll <- split(x, factors) %>%
        parallel::mclapply(fn, mc.cores = mc.cores, ...)

    mc_assert(ll)
    names(ll) <- NULL
    len <- vapply(ll, nrow, numeric(1)) %>% sum

    if (len == nrow(x))
        unsplit(ll, factors)
    else
        do.call(rbind, ll)
}

#' @export
wide_to_long <- function(df, id_vars = NULL) {
    df <- data.table::as.data.table(df)
    df <- data.table::melt(df,
                           id.vars = id_vars,
                           measure.vars = colnames(df)[!colnames(df) %in% id_vars],
                           variable.factor = F)
    # variable.factor = FALSE seems not to work
    df$variable <- as.character(df$variable)
    as.data.frame(df, stringsAsFactors = F)
}

#' @export
long_to_wide <- function(df, id_vars, id_var, value_var) {
    df <- data.table::as.data.table(df)
    df <- data.table::dcast(df,
                            as.formula(paste0(paste(id_vars, collapse = "+"), "~", id_var)),
                            value.var = value_var)
    as.data.frame(df, stringsAsFactors = F)
}


