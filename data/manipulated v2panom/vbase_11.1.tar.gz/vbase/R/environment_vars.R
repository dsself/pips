#' @export
is_path_mounted <- function(PATH = Sys.getenv("MOUNT_PATH")) {
	mm <- suppressWarnings(
			system("mountpoint " %^% PATH, 
				intern = TRUE, 
				ignore.stdout = FALSE, 
				ignore.stderr = TRUE))
	return(isTRUE(grepl("is a mountpoint", mm)))
}

#' @export
is_env_set <- function(ENVVAR) {
	return(Sys.getenv(ENVVAR) != "")
}
