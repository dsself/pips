#' @export 
named_list <- function(...) {
    return(setNames(list(...), unlist(as.list(match.call())[-1L])))
}


#' Replicate item as list for Map
#'
#' @export
list_replicate <- function(obj, n) {
    ll <- vector("list", n)
    for (i in 1:n) {    
        ll[[i]] <- obj 
    }
    return(ll)
}

#' Safe loading of list and data.frame elements
#'
#' @export
safe <- function(obj) {
    if(is.null(obj)) {
        stop("Object returns NULL!")
    }
    return(obj)
}

#' @export
list_remove_null <- function(ll) {
    ll[!(lapply(ll, is.null) %>% unlist)]
}

#' @export
list_remove_try_error <- function(ll) {
    ll[!(lapply(ll, is.try_error) %>% unlist)]
}

