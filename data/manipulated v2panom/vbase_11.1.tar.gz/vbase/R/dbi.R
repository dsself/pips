#'@export
schema_name <- function(name) {
    strsplit(name, ".", fixed = T) %>% unlist
}

#'@export
pg_create_table <- function(df, name, db, overwrite = FALSE, ...) {
    DBI::dbWriteTable(db,
                      name = schema_name(name),
                      value = df,
                      row.names = F,
                      overwrite = overwrite, ...)
}

#'@export
pg_create_table_types <- function(name, columns, types, db) {
    cols <- paste(columns, types, sep = " ") %>% paste(collapse = ", ")
    query <- "CREATE TABLE " %^% name %^% "(" %^% cols %^% ");"
    pg_send_query(db, query)
}

#'@export
pg_exists_table <- function(name, db) {
    DBI::dbExistsTable(db,
                       name = schema_name(name))
}

#'@export
pg_truncate_table <- function(name, db) {
    DBI::dbGetQuery(db, "TRUNCATE TABLE " %^% name %^% ";")
}

#'@export
pg_append_table <- function(df, name, db) {
    DBI::dbWriteTable(db,
                      name = schema_name(name),
                      value = df,
                      row.names = F,
                      append = T)
}

#'@export
pg_replace_table <- function(df, name, db) {
    pg_truncate_table(name, db)
    pg_append_table(df, name, db)
}

#'@export
pg_drop_table <- function(name, db) {
    DBI::dbGetQuery(db, "DROP TABLE " %^% name %^% ";")
}

#'@export
pg_send_query <- function(db, query) {
    DBI::dbGetQuery(conn = db, statement = query)
}

#'@export
pg_update_table <- function(df, name, db) {
    if (pg_exists_table(name, db)) {
        pg_truncate_table(name, db)
        pg_append_table(df, name, db)
    } else {
        pg_create_table(df, name, db)
    }
}

#'@export
pg_create_index <- function(column, name, db, unique_idx = F) {
    if (unique_idx) {
        unique_text = "UNIQUE "
    } else {
        unique_text = ""
    }

    pg_send_query(db,
        "CREATE " %^% unique_text %^% "INDEX ON " %^%
        name %^% " (" %^% column %^% ");")
}

#' Prepare string for postgres query
#'
#' @export
pg_text <- function(v) {
    cat(paste0("'", paste0(v, collapse = "','"), "'"), sep = "\n")
}